// 0x0E0003D0
const GeoLayout ccm_geo_0003D0[] = {
   GEO_CULLING_RADIUS(500),
   GEO_OPEN_NODE(),
      GEO_DISPLAY_LIST(LAYER_ALPHA, ccm_seg7_dl_07010F28),
      GEO_DISPLAY_LIST(LAYER_OPAQUE, ccm_seg7_dl_070118B0),
   GEO_CLOSE_NODE(),
   GEO_END(),
};
