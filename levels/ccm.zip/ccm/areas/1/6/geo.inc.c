// 0x0E00042C
const GeoLayout ccm_geo_00042C[] = {
   GEO_CULLING_RADIUS(800),
   GEO_OPEN_NODE(),
      GEO_RENDER_RANGE(-1000, 4000),
      GEO_OPEN_NODE(),
         GEO_DISPLAY_LIST(LAYER_OPAQUE, ccm_seg7_dl_0700E708),
         GEO_DISPLAY_LIST(LAYER_ALPHA, ccm_seg7_dl_0700E970),
      GEO_CLOSE_NODE(),
   GEO_CLOSE_NODE(),
   GEO_END(),
};
