ALIGNED8 u8 bowser_3_1__texture_0E000018[] = {
#include "levels/bowser_3/bowser_3_1_0xe000018_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_3_1__texture_0E001020[] = {
#include "levels/bowser_3/bowser_3_1_0xe001020_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_3_1__texture_0E001820[] = {
#include "levels/bowser_3/bowser_3_1_0xe001820_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_3_1__texture_0E002820[] = {
#include "levels/bowser_3/bowser_3_1_0xe002820_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_3_1__texture_0E003020[] = {
#include "levels/bowser_3/bowser_3_1_0xe003020_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_3_1__texture_0E003820[] = {
#include "levels/bowser_3/bowser_3_1_0xe003820_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_3_1__texture_0E004820[] = {
#include "levels/bowser_3/bowser_3_1_0xe004820_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_3_1__texture_0E005020[] = {
#include "levels/bowser_3/bowser_3_1_0xe005020_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_3_1__texture_0E005820[] = {
#include "levels/bowser_3/bowser_3_1_0xe005820_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_3_1__texture_0E006820[] = {
#include "levels/bowser_3/bowser_3_1_0xe006820_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_3_1__texture_0E007020[] = {
#include "levels/bowser_3/bowser_3_1_0xe007020_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_3_1__texture_0E007820[] = {
#include "levels/bowser_3/bowser_3_1_0xe007820_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_3_1__texture_0E008020[] = {
#include "levels/bowser_3/bowser_3_1_0xe008020_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_3_1__texture_0E009020[] = {
#include "levels/bowser_3/bowser_3_1_0xe009020_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_3_1__texture_0E00A020[] = {
#include "levels/bowser_3/bowser_3_1_0xe00a020_custom.ia8.inc.c"
};
ALIGNED8 u8 bowser_3_1__texture_0E00A820[] = {
#include "levels/bowser_3/bowser_3_1_0xe00a820_custom.ia8.inc.c"
};
ALIGNED8 u8 bowser_3_1__texture_0E00B820[] = {
#include "levels/bowser_3/bowser_3_1_0xe00b820_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_3_1__texture_0E00C820[] = {
#include "levels/bowser_3/bowser_3_1_0xe00c820_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_3_1__texture_0E00D820[] = {
#include "levels/bowser_3/bowser_3_1_0xe00d820_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_3_1__texture_0E00E020[] = {
#include "levels/bowser_3/bowser_3_1_0xe00e020_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_3_1__texture_0E00E820[] = {
#include "levels/bowser_3/bowser_3_1_0xe00e820_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_3_1__texture_0E00F020[] = {
#include "levels/bowser_3/bowser_3_1_0xe00f020_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_3_1__texture_0E00F820[] = {
#include "levels/bowser_3/bowser_3_1_0xe00f820_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_3_1__texture_0E010020[] = {
#include "levels/bowser_3/bowser_3_1_0xe010020_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_3_1__texture_0E010C20[] = {
#include "levels/bowser_3/bowser_3_1_0xe010c20_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_3_1__texture_0E011420[] = {
#include "levels/bowser_3/bowser_3_1_0xe011420_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_3_1__texture_0E011C20[] = {
#include "levels/bowser_3/bowser_3_1_0xe011c20_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_3_1__texture_0E013420[] = {
#include "levels/bowser_3/bowser_3_1_0xe013420_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_3_1__texture_0E016C20[] = {
#include "levels/bowser_3/bowser_3_1_0xe016c20_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_3_1__texture_0E017420[] = {
#include "levels/bowser_3/bowser_3_1_0xe017420_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_3_1__texture_0E017C20[] = {
#include "levels/bowser_3/bowser_3_1_0xe017c20_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_3_1__texture_0E018420[] = {
#include "levels/bowser_3/bowser_3_1_0xe018420_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_3_1__texture_0E018C20[] = {
#include "levels/bowser_3/bowser_3_1_0xe018c20_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_3_1__texture_0E019C20[] = {
#include "levels/bowser_3/bowser_3_1_0xe019c20_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_3_1__texture_0E01AC20[] = {
#include "levels/bowser_3/bowser_3_1_0xe01ac20_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_3_1__texture_0E01BC20[] = {
#include "levels/bowser_3/bowser_3_1_0xe01bc20_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_3_1__texture_0E01CC20[] = {
#include "levels/bowser_3/bowser_3_1_0xe01cc20_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_3_1__texture_0E01DC20[] = {
#include "levels/bowser_3/bowser_3_1_0xe01dc20_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_3_1__texture_0E01E420[] = {
#include "levels/bowser_3/bowser_3_1_0xe01e420_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_3_1__texture_0E01EC20[] = {
#include "levels/bowser_3/bowser_3_1_0xe01ec20_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_3_1__texture_0E008820[] = {
#include "levels/bowser_3/bowser_3_1_0xe008820_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_3_1__texture_0E00B420[] = {
#include "levels/bowser_3/bowser_3_1_0xe00b420_custom.ia8.inc.c"
};
ALIGNED8 u8 bowser_3_1__texture_0E00AC20[] = {
#include "levels/bowser_3/bowser_3_1_0xe00ac20_custom.rgba32.inc.c"
};
ALIGNED8 u8 bowser_3_1__texture_0E010820[] = {
#include "levels/bowser_3/bowser_3_1_0xe010820_custom.ia8.inc.c"
};
ALIGNED8 u8 bowser_3_1__texture_0E012420[] = {
#include "levels/bowser_3/bowser_3_1_0xe012420_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_3_1__texture_0E013C20[] = {
#include "levels/bowser_3/bowser_3_1_0xe013c20_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_3_1__texture_0E014C20[] = {
#include "levels/bowser_3/bowser_3_1_0xe014c20_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_3_1__texture_0E015C20[] = {
#include "levels/bowser_3/bowser_3_1_0xe015c20_custom.rgba16.inc.c"
};
