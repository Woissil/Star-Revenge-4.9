static Movtex bowser_3_1_Movtex_0_0[] = {0, 0, 15, 16, -6488, -10087, -1906, -10087, -1906, -7604, -6488, -7604, 1, 255, 0, 0};

const struct MovtexQuadCollection bowser_3_1_Movtex_0[] = {
{0,bowser_3_1_Movtex_0_0},
{-1, NULL},
};
const struct MovtexQuadCollection bowser_3_1_Movtex_1[] = {
{-1, NULL},
};
const struct MovtexQuadCollection bowser_3_1_Movtex_2[] = {
{-1, NULL},
};
