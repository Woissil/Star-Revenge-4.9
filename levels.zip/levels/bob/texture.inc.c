ALIGNED8 u8 bob_1__texture_0E000018[] = {
#include "levels/bob/bob_1_0xe000018_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_1__texture_0E000820[] = {
#include "levels/bob/bob_1_0xe000820_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_1__texture_0E001820[] = {
#include "levels/bob/bob_1_0xe001820_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_1__texture_0E002420[] = {
#include "levels/bob/bob_1_0xe002420_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_1__texture_0E002C20[] = {
#include "levels/bob/bob_1_0xe002c20_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_1__texture_0E003C20[] = {
#include "levels/bob/bob_1_0xe003c20_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_1__texture_0E004420[] = {
#include "levels/bob/bob_1_0xe004420_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_1__texture_0E005420[] = {
#include "levels/bob/bob_1_0xe005420_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_1__texture_0E005C20[] = {
#include "levels/bob/bob_1_0xe005c20_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_1__texture_0E006420[] = {
#include "levels/bob/bob_1_0xe006420_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_1__texture_0E007420[] = {
#include "levels/bob/bob_1_0xe007420_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_1__texture_0E008420[] = {
#include "levels/bob/bob_1_0xe008420_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_1__texture_0E008C20[] = {
#include "levels/bob/bob_1_0xe008c20_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_1__texture_0E009C20[] = {
#include "levels/bob/bob_1_0xe009c20_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_1__texture_0E00AC20[] = {
#include "levels/bob/bob_1_0xe00ac20_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_1__texture_0E00B420[] = {
#include "levels/bob/bob_1_0xe00b420_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_1__texture_0E00BC20[] = {
#include "levels/bob/bob_1_0xe00bc20_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_1__texture_0E00CC20[] = {
#include "levels/bob/bob_1_0xe00cc20_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_1__texture_0E00DC20[] = {
#include "levels/bob/bob_1_0xe00dc20_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_1__texture_0E00EC20[] = {
#include "levels/bob/bob_1_0xe00ec20_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_1__texture_0E00F420[] = {
#include "levels/bob/bob_1_0xe00f420_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_1__texture_0E010420[] = {
#include "levels/bob/bob_1_0xe010420_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_1__texture_0E010C20[] = {
#include "levels/bob/bob_1_0xe010c20_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_1__texture_0E011420[] = {
#include "levels/bob/bob_1_0xe011420_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_1__texture_0E011C20[] = {
#include "levels/bob/bob_1_0xe011c20_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_1__texture_0E012C20[] = {
#include "levels/bob/bob_1_0xe012c20_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_1__texture_0E013C20[] = {
#include "levels/bob/bob_1_0xe013c20_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_1__texture_0E014420[] = {
#include "levels/bob/bob_1_0xe014420_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_1__texture_0E015420[] = {
#include "levels/bob/bob_1_0xe015420_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_1__texture_0E016420[] = {
#include "levels/bob/bob_1_0xe016420_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_1__texture_0E017420[] = {
#include "levels/bob/bob_1_0xe017420_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_1__texture_0E017C20[] = {
#include "levels/bob/bob_1_0xe017c20_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_1__texture_0E018420[] = {
#include "levels/bob/bob_1_0xe018420_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_1__texture_0E019420[] = {
#include "levels/bob/bob_1_0xe019420_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_1__texture_0E019C20[] = {
#include "levels/bob/bob_1_0xe019c20_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_1__texture_0E01A420[] = {
#include "levels/bob/bob_1_0xe01a420_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_1__texture_0E01AC20[] = {
#include "levels/bob/bob_1_0xe01ac20_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_1__texture_0E01B420[] = {
#include "levels/bob/bob_1_0xe01b420_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_1__texture_0E01BC20[] = {
#include "levels/bob/bob_1_0xe01bc20_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_1__texture_0E01C420[] = {
#include "levels/bob/bob_1_0xe01c420_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_1__texture_0E01D420[] = {
#include "levels/bob/bob_1_0xe01d420_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_1__texture_0E01F420[] = {
#include "levels/bob/bob_1_0xe01f420_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_1__texture_0E01FC20[] = {
#include "levels/bob/bob_1_0xe01fc20_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_1__texture_0E020420[] = {
#include "levels/bob/bob_1_0xe020420_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_1__texture_0E020C20[] = {
#include "levels/bob/bob_1_0xe020c20_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_1__texture_0E021C20[] = {
#include "levels/bob/bob_1_0xe021c20_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_1__texture_0E022420[] = {
#include "levels/bob/bob_1_0xe022420_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_1__texture_0E022C20[] = {
#include "levels/bob/bob_1_0xe022c20_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_1__texture_0E025C20[] = {
#include "levels/bob/bob_1_0xe025c20_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_1__texture_0E026420[] = {
#include "levels/bob/bob_1_0xe026420_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_1__texture_0E026C20[] = {
#include "levels/bob/bob_1_0xe026c20_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_1__texture_0E027C20[] = {
#include "levels/bob/bob_1_0xe027c20_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_1__texture_0E028C20[] = {
#include "levels/bob/bob_1_0xe028c20_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_1__texture_0E029C20[] = {
#include "levels/bob/bob_1_0xe029c20_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_1__texture_0E02AC20[] = {
#include "levels/bob/bob_1_0xe02ac20_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_1__texture_0E02D420[] = {
#include "levels/bob/bob_1_0xe02d420_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_1__texture_0E02DC20[] = {
#include "levels/bob/bob_1_0xe02dc20_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_1__texture_0E002020[] = {
#include "levels/bob/bob_1_0xe002020_custom.ia8.inc.c"
};
ALIGNED8 u8 bob_1__texture_0E004C20[] = {
#include "levels/bob/bob_1_0xe004c20_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_1__texture_0E023C20[] = {
#include "levels/bob/bob_1_0xe023c20_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_1__texture_0E024420[] = {
#include "levels/bob/bob_1_0xe024420_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_1__texture_0E024C20[] = {
#include "levels/bob/bob_1_0xe024c20_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_1__texture_0E02BC20[] = {
#include "levels/bob/bob_1_0xe02bc20_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_1__texture_0E02C420[] = {
#include "levels/bob/bob_1_0xe02c420_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_1__texture_0E01E420[] = {
#include "levels/bob/bob_1_0xe01e420_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_1__texture_0E01EC20[] = {
#include "levels/bob/bob_1_0xe01ec20_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_1__texture_0E021420[] = {
#include "levels/bob/bob_1_0xe021420_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_1__texture_0E023420[] = {
#include "levels/bob/bob_1_0xe023420_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_1__texture_0E025420[] = {
#include "levels/bob/bob_1_0xe025420_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_1__texture_0E02EC20[] = {
#include "levels/bob/bob_1_0xe02ec20_custom.rgba16.inc.c"
};
