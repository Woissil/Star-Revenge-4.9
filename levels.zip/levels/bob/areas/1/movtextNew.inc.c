static Movtex bob_1_Movtex_0_0[] = {1, 0, 15, 16, -13788, -9800, -3657, -9800, -3657, -5627, -13788, -5627, 1, 0, 0, 0};

static Movtex bob_1_Movtex_1_0[] = {1, 0, 15, 16, -3653, -12622, 10386, -12622, 10386, -5029, -3653, -5029, 1, 0, 0, 0};

const struct MovtexQuadCollection bob_1_Movtex_0[] = {
{0,bob_1_Movtex_0_0},
{1,bob_1_Movtex_1_0},
{-1, NULL},
};
const struct MovtexQuadCollection bob_1_Movtex_1[] = {
{-1, NULL},
};
const struct MovtexQuadCollection bob_1_Movtex_2[] = {
{-1, NULL},
};
