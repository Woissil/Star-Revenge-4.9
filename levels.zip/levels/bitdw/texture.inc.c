ALIGNED8 u8 bitdw_1__texture_0E000820[] = {
#include "levels/bitdw/bitdw_1_0xe000820_custom.rgba16.inc.c"
};
ALIGNED8 u8 bitdw_1__texture_0E001420[] = {
#include "levels/bitdw/bitdw_1_0xe001420_custom.rgba16.inc.c"
};
ALIGNED8 u8 bitdw_1__texture_0E002420[] = {
#include "levels/bitdw/bitdw_1_0xe002420_custom.rgba16.inc.c"
};
ALIGNED8 u8 bitdw_1__texture_0E003420[] = {
#include "levels/bitdw/bitdw_1_0xe003420_custom.rgba16.inc.c"
};
ALIGNED8 u8 bitdw_1__texture_0E003C20[] = {
#include "levels/bitdw/bitdw_1_0xe003c20_custom.rgba16.inc.c"
};
ALIGNED8 u8 bitdw_1__texture_0E004420[] = {
#include "levels/bitdw/bitdw_1_0xe004420_custom.rgba16.inc.c"
};
ALIGNED8 u8 bitdw_1__texture_0E005420[] = {
#include "levels/bitdw/bitdw_1_0xe005420_custom.rgba16.inc.c"
};
ALIGNED8 u8 bitdw_1__texture_0E006420[] = {
#include "levels/bitdw/bitdw_1_0xe006420_custom.rgba16.inc.c"
};
ALIGNED8 u8 bitdw_1__texture_0E007420[] = {
#include "levels/bitdw/bitdw_1_0xe007420_custom.rgba16.inc.c"
};
ALIGNED8 u8 bitdw_1__texture_0E008420[] = {
#include "levels/bitdw/bitdw_1_0xe008420_custom.rgba16.inc.c"
};
ALIGNED8 u8 bitdw_1__texture_0E009420[] = {
#include "levels/bitdw/bitdw_1_0xe009420_custom.rgba16.inc.c"
};
ALIGNED8 u8 bitdw_1__texture_0E009C20[] = {
#include "levels/bitdw/bitdw_1_0xe009c20_custom.rgba16.inc.c"
};
ALIGNED8 u8 bitdw_1__texture_0E00A420[] = {
#include "levels/bitdw/bitdw_1_0xe00a420_custom.rgba16.inc.c"
};
ALIGNED8 u8 bitdw_1__texture_0E00AC20[] = {
#include "levels/bitdw/bitdw_1_0xe00ac20_custom.rgba16.inc.c"
};
ALIGNED8 u8 bitdw_1__texture_0E00B420[] = {
#include "levels/bitdw/bitdw_1_0xe00b420_custom.rgba16.inc.c"
};
ALIGNED8 u8 bitdw_1__texture_0E00C420[] = {
#include "levels/bitdw/bitdw_1_0xe00c420_custom.rgba16.inc.c"
};
ALIGNED8 u8 bitdw_1__texture_0E00D420[] = {
#include "levels/bitdw/bitdw_1_0xe00d420_custom.rgba16.inc.c"
};
ALIGNED8 u8 bitdw_1__texture_0E00E020[] = {
#include "levels/bitdw/bitdw_1_0xe00e020_custom.rgba16.inc.c"
};
ALIGNED8 u8 bitdw_1__texture_0E00EC20[] = {
#include "levels/bitdw/bitdw_1_0xe00ec20_custom.rgba16.inc.c"
};
ALIGNED8 u8 bitdw_1__texture_0E00FC20[] = {
#include "levels/bitdw/bitdw_1_0xe00fc20_custom.rgba16.inc.c"
};
ALIGNED8 u8 bitdw_1__texture_0E010C20[] = {
#include "levels/bitdw/bitdw_1_0xe010c20_custom.rgba16.inc.c"
};
ALIGNED8 u8 bitdw_1__texture_0E012C20[] = {
#include "levels/bitdw/bitdw_1_0xe012c20_custom.rgba16.inc.c"
};
ALIGNED8 u8 bitdw_1__texture_0E013420[] = {
#include "levels/bitdw/bitdw_1_0xe013420_custom.rgba16.inc.c"
};
ALIGNED8 u8 bitdw_1__texture_0E015C20[] = {
#include "levels/bitdw/bitdw_1_0xe015c20_custom.rgba16.inc.c"
};
ALIGNED8 u8 bitdw_1__texture_0E016420[] = {
#include "levels/bitdw/bitdw_1_0xe016420_custom.rgba16.inc.c"
};
ALIGNED8 u8 bitdw_1__texture_0E016C20[] = {
#include "levels/bitdw/bitdw_1_0xe016c20_custom.rgba16.inc.c"
};
ALIGNED8 u8 bitdw_1__texture_0E018C20[] = {
#include "levels/bitdw/bitdw_1_0xe018c20_custom.rgba16.inc.c"
};
ALIGNED8 u8 bitdw_1__texture_0E019420[] = {
#include "levels/bitdw/bitdw_1_0xe019420_custom.rgba16.inc.c"
};
ALIGNED8 u8 bitdw_1__texture_0E01AC20[] = {
#include "levels/bitdw/bitdw_1_0xe01ac20_custom.rgba16.inc.c"
};
ALIGNED8 u8 bitdw_1__texture_0E01BC20[] = {
#include "levels/bitdw/bitdw_1_0xe01bc20_custom.rgba16.inc.c"
};
ALIGNED8 u8 bitdw_1__texture_0E01CC20[] = {
#include "levels/bitdw/bitdw_1_0xe01cc20_custom.rgba16.inc.c"
};
ALIGNED8 u8 bitdw_1__texture_0E01D420[] = {
#include "levels/bitdw/bitdw_1_0xe01d420_custom.rgba16.inc.c"
};
ALIGNED8 u8 bitdw_1__texture_0E000018[] = {
#include "levels/bitdw/bitdw_1_0xe000018_custom.rgba32.inc.c"
};
ALIGNED8 u8 bitdw_1__texture_0E002C20[] = {
#include "levels/bitdw/bitdw_1_0xe002c20_custom.rgba16.inc.c"
};
ALIGNED8 u8 bitdw_1__texture_0E00F420[] = {
#include "levels/bitdw/bitdw_1_0xe00f420_custom.rgba16.inc.c"
};
ALIGNED8 u8 bitdw_1__texture_0E011420[] = {
#include "levels/bitdw/bitdw_1_0xe011420_custom.rgba16.inc.c"
};
ALIGNED8 u8 bitdw_1__texture_0E011C20[] = {
#include "levels/bitdw/bitdw_1_0xe011c20_custom.rgba16.inc.c"
};
ALIGNED8 u8 bitdw_1__texture_0E017420[] = {
#include "levels/bitdw/bitdw_1_0xe017420_custom.rgba16.inc.c"
};
ALIGNED8 u8 bitdw_1__texture_0E017C20[] = {
#include "levels/bitdw/bitdw_1_0xe017c20_custom.rgba16.inc.c"
};
ALIGNED8 u8 bitdw_1__texture_0E019C20[] = {
#include "levels/bitdw/bitdw_1_0xe019c20_custom.rgba32.inc.c"
};
ALIGNED8 u8 bitdw_1__texture_0E01DC20[] = {
#include "levels/bitdw/bitdw_1_0xe01dc20_custom.rgba16.inc.c"
};
ALIGNED8 u8 bitdw_1__texture_0E001020[] = {
#include "levels/bitdw/bitdw_1_0xe001020_custom.ci8.inc.c"
};
ALIGNED8 u8 bitdw_1__texture_0E001220[] = {
#include "levels/bitdw/bitdw_1_0xe001020_custom.ci8.pal.inc.c"
};
ALIGNED8 u8 bitdw_1__texture_0E007C20[] = {
#include "levels/bitdw/bitdw_1_0xe007c20_custom.rgba32.inc.c"
};
ALIGNED8 u8 bitdw_1__texture_0E00DC20[] = {
#include "levels/bitdw/bitdw_1_0xe00dc20_custom.ci8.inc.c"
};
ALIGNED8 u8 bitdw_1__texture_0E00DE20[] = {
#include "levels/bitdw/bitdw_1_0xe00dc20_custom.ci8.pal.inc.c"
};
ALIGNED8 u8 bitdw_1__texture_0E00E820[] = {
#include "levels/bitdw/bitdw_1_0xe00e820_custom.ci8.inc.c"
};
ALIGNED8 u8 bitdw_1__texture_0E00EA20[] = {
#include "levels/bitdw/bitdw_1_0xe00e820_custom.ci8.pal.inc.c"
};
ALIGNED8 u8 bitdw_1__texture_0E013C20[] = {
#include "levels/bitdw/bitdw_1_0xe013c20_custom.rgba32.inc.c"
};
ALIGNED8 u8 bitdw_1__texture_0E014C20[] = {
#include "levels/bitdw/bitdw_1_0xe014c20_custom.rgba32.inc.c"
};
