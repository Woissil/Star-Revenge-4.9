// 0x0E000510
const GeoLayout geo_bitdw_000510[] = {
   GEO_CULLING_RADIUS(1400),
   GEO_OPEN_NODE(),
      GEO_DISPLAY_LIST(LAYER_OPAQUE, bitdw_seg7_dl_0700AD10),
   GEO_CLOSE_NODE(),
   GEO_END(),
};
