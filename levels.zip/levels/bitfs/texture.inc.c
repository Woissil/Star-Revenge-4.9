ALIGNED8 u8 bitfs_1__texture_0E000018[] = {
#include "levels/bitfs/bitfs_1_0xe000018_custom.rgba16.inc.c"
};
ALIGNED8 u8 bitfs_1__texture_0E001020[] = {
#include "levels/bitfs/bitfs_1_0xe001020_custom.rgba16.inc.c"
};
ALIGNED8 u8 bitfs_1__texture_0E001820[] = {
#include "levels/bitfs/bitfs_1_0xe001820_custom.rgba16.inc.c"
};
ALIGNED8 u8 bitfs_1__texture_0E002020[] = {
#include "levels/bitfs/bitfs_1_0xe002020_custom.rgba16.inc.c"
};
ALIGNED8 u8 bitfs_1__texture_0E002820[] = {
#include "levels/bitfs/bitfs_1_0xe002820_custom.rgba16.inc.c"
};
ALIGNED8 u8 bitfs_1__texture_0E003020[] = {
#include "levels/bitfs/bitfs_1_0xe003020_custom.rgba16.inc.c"
};
ALIGNED8 u8 bitfs_1__texture_0E003820[] = {
#include "levels/bitfs/bitfs_1_0xe003820_custom.rgba16.inc.c"
};
ALIGNED8 u8 bitfs_1__texture_0E004820[] = {
#include "levels/bitfs/bitfs_1_0xe004820_custom.rgba16.inc.c"
};
ALIGNED8 u8 bitfs_1__texture_0E005020[] = {
#include "levels/bitfs/bitfs_1_0xe005020_custom.rgba16.inc.c"
};
ALIGNED8 u8 bitfs_1__texture_0E005820[] = {
#include "levels/bitfs/bitfs_1_0xe005820_custom.rgba16.inc.c"
};
ALIGNED8 u8 bitfs_1__texture_0E006020[] = {
#include "levels/bitfs/bitfs_1_0xe006020_custom.rgba16.inc.c"
};
ALIGNED8 u8 bitfs_1__texture_0E006820[] = {
#include "levels/bitfs/bitfs_1_0xe006820_custom.rgba16.inc.c"
};
ALIGNED8 u8 bitfs_1__texture_0E007020[] = {
#include "levels/bitfs/bitfs_1_0xe007020_custom.rgba16.inc.c"
};
ALIGNED8 u8 bitfs_1__texture_0E007820[] = {
#include "levels/bitfs/bitfs_1_0xe007820_custom.rgba16.inc.c"
};
ALIGNED8 u8 bitfs_1__texture_0E008820[] = {
#include "levels/bitfs/bitfs_1_0xe008820_custom.rgba16.inc.c"
};
ALIGNED8 u8 bitfs_1__texture_0E009020[] = {
#include "levels/bitfs/bitfs_1_0xe009020_custom.rgba16.inc.c"
};
ALIGNED8 u8 bitfs_1__texture_0E009820[] = {
#include "levels/bitfs/bitfs_1_0xe009820_custom.rgba16.inc.c"
};
ALIGNED8 u8 bitfs_1__texture_0E00A820[] = {
#include "levels/bitfs/bitfs_1_0xe00a820_custom.rgba16.inc.c"
};
ALIGNED8 u8 bitfs_1__texture_0E00C020[] = {
#include "levels/bitfs/bitfs_1_0xe00c020_custom.rgba16.inc.c"
};
ALIGNED8 u8 bitfs_1__texture_0E00C820[] = {
#include "levels/bitfs/bitfs_1_0xe00c820_custom.rgba16.inc.c"
};
ALIGNED8 u8 bitfs_1__texture_0E00D820[] = {
#include "levels/bitfs/bitfs_1_0xe00d820_custom.rgba16.inc.c"
};
ALIGNED8 u8 bitfs_1__texture_0E00E820[] = {
#include "levels/bitfs/bitfs_1_0xe00e820_custom.rgba16.inc.c"
};
ALIGNED8 u8 bitfs_1__texture_0E00F820[] = {
#include "levels/bitfs/bitfs_1_0xe00f820_custom.rgba16.inc.c"
};
ALIGNED8 u8 bitfs_1__texture_0E010820[] = {
#include "levels/bitfs/bitfs_1_0xe010820_custom.rgba16.inc.c"
};
ALIGNED8 u8 bitfs_1__texture_0E011820[] = {
#include "levels/bitfs/bitfs_1_0xe011820_custom.rgba16.inc.c"
};
ALIGNED8 u8 bitfs_1__texture_0E012820[] = {
#include "levels/bitfs/bitfs_1_0xe012820_custom.rgba16.inc.c"
};
ALIGNED8 u8 bitfs_1__texture_0E013020[] = {
#include "levels/bitfs/bitfs_1_0xe013020_custom.rgba16.inc.c"
};
ALIGNED8 u8 bitfs_1__texture_0E013820[] = {
#include "levels/bitfs/bitfs_1_0xe013820_custom.rgba16.inc.c"
};
ALIGNED8 u8 bitfs_1__texture_0E014020[] = {
#include "levels/bitfs/bitfs_1_0xe014020_custom.rgba16.inc.c"
};
ALIGNED8 u8 bitfs_1__texture_0E014820[] = {
#include "levels/bitfs/bitfs_1_0xe014820_custom.rgba16.inc.c"
};
ALIGNED8 u8 bitfs_1__texture_0E015820[] = {
#include "levels/bitfs/bitfs_1_0xe015820_custom.rgba16.inc.c"
};
ALIGNED8 u8 bitfs_1__texture_0E016020[] = {
#include "levels/bitfs/bitfs_1_0xe016020_custom.rgba16.inc.c"
};
ALIGNED8 u8 bitfs_1__texture_0E016820[] = {
#include "levels/bitfs/bitfs_1_0xe016820_custom.rgba16.inc.c"
};
ALIGNED8 u8 bitfs_1__texture_0E017020[] = {
#include "levels/bitfs/bitfs_1_0xe017020_custom.rgba16.inc.c"
};
ALIGNED8 u8 bitfs_1__texture_0E017820[] = {
#include "levels/bitfs/bitfs_1_0xe017820_custom.rgba16.inc.c"
};
ALIGNED8 u8 bitfs_1__texture_0E018020[] = {
#include "levels/bitfs/bitfs_1_0xe018020_custom.rgba16.inc.c"
};
ALIGNED8 u8 bitfs_1__texture_0E018820[] = {
#include "levels/bitfs/bitfs_1_0xe018820_custom.rgba16.inc.c"
};
ALIGNED8 u8 bitfs_1__texture_0E019020[] = {
#include "levels/bitfs/bitfs_1_0xe019020_custom.rgba16.inc.c"
};
ALIGNED8 u8 bitfs_1__texture_0E019820[] = {
#include "levels/bitfs/bitfs_1_0xe019820_custom.rgba16.inc.c"
};
ALIGNED8 u8 bitfs_1__texture_0E01A020[] = {
#include "levels/bitfs/bitfs_1_0xe01a020_custom.rgba16.inc.c"
};
ALIGNED8 u8 bitfs_1__texture_0E01B020[] = {
#include "levels/bitfs/bitfs_1_0xe01b020_custom.rgba16.inc.c"
};
ALIGNED8 u8 bitfs_1__texture_0E01D020[] = {
#include "levels/bitfs/bitfs_1_0xe01d020_custom.rgba16.inc.c"
};
ALIGNED8 u8 bitfs_1__texture_0E01DC20[] = {
#include "levels/bitfs/bitfs_1_0xe01dc20_custom.rgba16.inc.c"
};
ALIGNED8 u8 bitfs_1__texture_0E00B020[] = {
#include "levels/bitfs/bitfs_1_0xe00b020_custom.ci8.inc.c"
};
ALIGNED8 u8 bitfs_1__texture_0E00B820[] = {
#include "levels/bitfs/bitfs_1_0xe00b020_custom.ci8.pal.inc.c"
};
ALIGNED8 u8 bitfs_1__texture_0E00BA20[] = {
#include "levels/bitfs/bitfs_1_0xe00ba20_custom.ci8.inc.c"
};
ALIGNED8 u8 bitfs_1__texture_0E00BE20[] = {
#include "levels/bitfs/bitfs_1_0xe00ba20_custom.ci8.pal.inc.c"
};
ALIGNED8 u8 bitfs_1__texture_0E01D820[] = {
#include "levels/bitfs/bitfs_1_0xe01d820_custom.ia8.inc.c"
};
ALIGNED8 u8 bitfs_1__texture_0E01B820[] = {
#include "levels/bitfs/bitfs_1_0xe01b820_custom.rgba16.inc.c"
};
ALIGNED8 u8 bitfs_1__texture_0E01C020[] = {
#include "levels/bitfs/bitfs_1_0xe01c020_custom.rgba16.inc.c"
};
ALIGNED8 u8 bitfs_1__texture_0E01C820[] = {
#include "levels/bitfs/bitfs_1_0xe01c820_custom.rgba16.inc.c"
};
