// 0x0E000618
const GeoLayout bitfs_geo_000618[] = {
   GEO_CULLING_RADIUS(2500),
   GEO_OPEN_NODE(),
      GEO_DISPLAY_LIST(LAYER_ALPHA, bitfs_seg7_dl_0700C3C0),
   GEO_CLOSE_NODE(),
   GEO_END(),
};
