ALIGNED8 u8 bits_2__texture_0E000018[] = {
#include "levels/bits/bits_2_0xe000018_custom.rgba16.inc.c"
};
ALIGNED8 u8 bits_2__texture_0E000820[] = {
#include "levels/bits/bits_2_0xe000820_custom.rgba16.inc.c"
};
ALIGNED8 u8 bits_2__texture_0E001820[] = {
#include "levels/bits/bits_2_0xe001820_custom.rgba16.inc.c"
};
ALIGNED8 u8 bits_2__texture_0E002020[] = {
#include "levels/bits/bits_2_0xe002020_custom.rgba16.inc.c"
};
ALIGNED8 u8 bits_2__texture_0E002820[] = {
#include "levels/bits/bits_2_0xe002820_custom.rgba16.inc.c"
};
ALIGNED8 u8 bits_2__texture_0E003020[] = {
#include "levels/bits/bits_2_0xe003020_custom.rgba16.inc.c"
};
ALIGNED8 u8 bits_2__texture_0E003820[] = {
#include "levels/bits/bits_2_0xe003820_custom.rgba16.inc.c"
};
ALIGNED8 u8 bits_2__texture_0E004020[] = {
#include "levels/bits/bits_2_0xe004020_custom.rgba16.inc.c"
};
ALIGNED8 u8 bits_2__texture_0E004820[] = {
#include "levels/bits/bits_2_0xe004820_custom.rgba16.inc.c"
};
ALIGNED8 u8 bits_2__texture_0E005020[] = {
#include "levels/bits/bits_2_0xe005020_custom.rgba16.inc.c"
};
ALIGNED8 u8 bits_2__texture_0E005820[] = {
#include "levels/bits/bits_2_0xe005820_custom.rgba16.inc.c"
};
ALIGNED8 u8 bits_2__texture_0E006020[] = {
#include "levels/bits/bits_2_0xe006020_custom.rgba16.inc.c"
};
ALIGNED8 u8 bits_2__texture_0E007020[] = {
#include "levels/bits/bits_2_0xe007020_custom.rgba16.inc.c"
};
ALIGNED8 u8 bits_2__texture_0E008020[] = {
#include "levels/bits/bits_2_0xe008020_custom.rgba16.inc.c"
};
ALIGNED8 u8 bits_2__texture_0E009020[] = {
#include "levels/bits/bits_2_0xe009020_custom.rgba16.inc.c"
};
ALIGNED8 u8 bits_2__texture_0E009820[] = {
#include "levels/bits/bits_2_0xe009820_custom.rgba16.inc.c"
};
ALIGNED8 u8 bits_2__texture_0E00A020[] = {
#include "levels/bits/bits_2_0xe00a020_custom.rgba16.inc.c"
};
ALIGNED8 u8 bits_2__texture_0E00B020[] = {
#include "levels/bits/bits_2_0xe00b020_custom.rgba16.inc.c"
};
ALIGNED8 u8 bits_2__texture_0E00B820[] = {
#include "levels/bits/bits_2_0xe00b820_custom.rgba16.inc.c"
};
ALIGNED8 u8 bits_2__texture_0E00C020[] = {
#include "levels/bits/bits_2_0xe00c020_custom.rgba16.inc.c"
};
ALIGNED8 u8 bits_2__texture_0E00D820[] = {
#include "levels/bits/bits_2_0xe00d820_custom.rgba16.inc.c"
};
ALIGNED8 u8 bits_2__texture_0E00E820[] = {
#include "levels/bits/bits_2_0xe00e820_custom.rgba16.inc.c"
};
ALIGNED8 u8 bits_2__texture_0E00F020[] = {
#include "levels/bits/bits_2_0xe00f020_custom.rgba16.inc.c"
};
ALIGNED8 u8 bits_2__texture_0E00F820[] = {
#include "levels/bits/bits_2_0xe00f820_custom.rgba16.inc.c"
};
ALIGNED8 u8 bits_2__texture_0E010020[] = {
#include "levels/bits/bits_2_0xe010020_custom.rgba16.inc.c"
};
ALIGNED8 u8 bits_2__texture_0E014820[] = {
#include "levels/bits/bits_2_0xe014820_custom.rgba16.inc.c"
};
ALIGNED8 u8 bits_2__texture_0E015020[] = {
#include "levels/bits/bits_2_0xe015020_custom.rgba16.inc.c"
};
ALIGNED8 u8 bits_2__texture_0E015820[] = {
#include "levels/bits/bits_2_0xe015820_custom.rgba16.inc.c"
};
ALIGNED8 u8 bits_2__texture_0E016020[] = {
#include "levels/bits/bits_2_0xe016020_custom.rgba16.inc.c"
};
ALIGNED8 u8 bits_2__texture_0E016820[] = {
#include "levels/bits/bits_2_0xe016820_custom.rgba16.inc.c"
};
ALIGNED8 u8 bits_2__texture_0E017020[] = {
#include "levels/bits/bits_2_0xe017020_custom.rgba16.inc.c"
};
ALIGNED8 u8 bits_2__texture_0E018020[] = {
#include "levels/bits/bits_2_0xe018020_custom.rgba16.inc.c"
};
ALIGNED8 u8 bits_2__texture_0E019020[] = {
#include "levels/bits/bits_2_0xe019020_custom.rgba16.inc.c"
};
ALIGNED8 u8 bits_2__texture_0E01A020[] = {
#include "levels/bits/bits_2_0xe01a020_custom.rgba16.inc.c"
};
ALIGNED8 u8 bits_2__texture_0E01B020[] = {
#include "levels/bits/bits_2_0xe01b020_custom.rgba16.inc.c"
};
ALIGNED8 u8 bits_2__texture_0E01B820[] = {
#include "levels/bits/bits_2_0xe01b820_custom.rgba16.inc.c"
};
ALIGNED8 u8 bits_2__texture_0E01C020[] = {
#include "levels/bits/bits_2_0xe01c020_custom.rgba16.inc.c"
};
ALIGNED8 u8 bits_2__texture_0E01D020[] = {
#include "levels/bits/bits_2_0xe01d020_custom.rgba16.inc.c"
};
ALIGNED8 u8 bits_2__texture_0E01E020[] = {
#include "levels/bits/bits_2_0xe01e020_custom.rgba16.inc.c"
};
ALIGNED8 u8 bits_2__texture_0E022020[] = {
#include "levels/bits/bits_2_0xe022020_custom.rgba16.inc.c"
};
ALIGNED8 u8 bits_2__texture_0E022820[] = {
#include "levels/bits/bits_2_0xe022820_custom.rgba16.inc.c"
};
ALIGNED8 u8 bits_2__texture_0E023020[] = {
#include "levels/bits/bits_2_0xe023020_custom.rgba16.inc.c"
};
ALIGNED8 u8 bits_2__texture_0E024020[] = {
#include "levels/bits/bits_2_0xe024020_custom.rgba16.inc.c"
};
ALIGNED8 u8 bits_2__texture_0E024820[] = {
#include "levels/bits/bits_2_0xe024820_custom.rgba16.inc.c"
};
ALIGNED8 u8 bits_2__texture_0E025020[] = {
#include "levels/bits/bits_2_0xe025020_custom.rgba16.inc.c"
};
ALIGNED8 u8 bits_2__texture_0E026420[] = {
#include "levels/bits/bits_2_0xe026420_custom.rgba16.inc.c"
};
ALIGNED8 u8 bits_2__texture_0E027420[] = {
#include "levels/bits/bits_2_0xe027420_custom.rgba16.inc.c"
};
ALIGNED8 u8 bits_2__texture_0E027C20[] = {
#include "levels/bits/bits_2_0xe027c20_custom.rgba16.inc.c"
};
ALIGNED8 u8 bits_2__texture_0E028C20[] = {
#include "levels/bits/bits_2_0xe028c20_custom.rgba16.inc.c"
};
ALIGNED8 u8 bits_2__texture_0E029420[] = {
#include "levels/bits/bits_2_0xe029420_custom.rgba16.inc.c"
};
ALIGNED8 u8 bits_2__texture_0E02A420[] = {
#include "levels/bits/bits_2_0xe02a420_custom.rgba16.inc.c"
};
ALIGNED8 u8 bits_2__texture_0E02AC20[] = {
#include "levels/bits/bits_2_0xe02ac20_custom.rgba16.inc.c"
};
ALIGNED8 u8 bits_2__texture_0E02B420[] = {
#include "levels/bits/bits_2_0xe02b420_custom.rgba16.inc.c"
};
ALIGNED8 u8 bits_2__texture_0E02BC20[] = {
#include "levels/bits/bits_2_0xe02bc20_custom.rgba16.inc.c"
};
ALIGNED8 u8 bits_2__texture_0E02CC20[] = {
#include "levels/bits/bits_2_0xe02cc20_custom.rgba16.inc.c"
};
ALIGNED8 u8 bits_2__texture_0E02D420[] = {
#include "levels/bits/bits_2_0xe02d420_custom.rgba16.inc.c"
};
ALIGNED8 u8 bits_2__texture_0E02DC20[] = {
#include "levels/bits/bits_2_0xe02dc20_custom.rgba16.inc.c"
};
ALIGNED8 u8 bits_2__texture_0E02E420[] = {
#include "levels/bits/bits_2_0xe02e420_custom.rgba16.inc.c"
};
ALIGNED8 u8 bits_2__texture_0E02F420[] = {
#include "levels/bits/bits_2_0xe02f420_custom.rgba16.inc.c"
};
ALIGNED8 u8 bits_2__texture_0E030420[] = {
#include "levels/bits/bits_2_0xe030420_custom.rgba16.inc.c"
};
ALIGNED8 u8 bits_2__texture_0E030C20[] = {
#include "levels/bits/bits_2_0xe030c20_custom.rgba16.inc.c"
};
ALIGNED8 u8 bits_2__texture_0E031420[] = {
#include "levels/bits/bits_2_0xe031420_custom.rgba16.inc.c"
};
ALIGNED8 u8 bits_2__texture_0E032420[] = {
#include "levels/bits/bits_2_0xe032420_custom.rgba16.inc.c"
};
ALIGNED8 u8 bits_2__texture_0E033420[] = {
#include "levels/bits/bits_2_0xe033420_custom.rgba16.inc.c"
};
ALIGNED8 u8 bits_2__texture_0E00C820[] = {
#include "levels/bits/bits_2_0xe00c820_custom.rgba16.inc.c"
};
ALIGNED8 u8 bits_2__texture_0E00D020[] = {
#include "levels/bits/bits_2_0xe00d020_custom.rgba16.inc.c"
};
ALIGNED8 u8 bits_2__texture_0E012820[] = {
#include "levels/bits/bits_2_0xe012820_custom.rgba16.inc.c"
};
ALIGNED8 u8 bits_2__texture_0E013020[] = {
#include "levels/bits/bits_2_0xe013020_custom.rgba32.inc.c"
};
ALIGNED8 u8 bits_2__texture_0E01F020[] = {
#include "levels/bits/bits_2_0xe01f020_custom.rgba16.inc.c"
};
ALIGNED8 u8 bits_2__texture_0E020020[] = {
#include "levels/bits/bits_2_0xe020020_custom.rgba16.inc.c"
};
ALIGNED8 u8 bits_2__texture_0E021020[] = {
#include "levels/bits/bits_2_0xe021020_custom.rgba16.inc.c"
};
ALIGNED8 u8 bits_2__texture_0E025820[] = {
#include "levels/bits/bits_2_0xe025820_custom.rgba16.inc.c"
};
ALIGNED8 u8 bits_2__texture_0E029C20[] = {
#include "levels/bits/bits_2_0xe029c20_custom.rgba16.inc.c"
};
ALIGNED8 u8 bits_2__texture_0E02C420[] = {
#include "levels/bits/bits_2_0xe02c420_custom.rgba16.inc.c"
};
ALIGNED8 u8 bits_2__texture_0E010820[] = {
#include "levels/bits/bits_2_0xe010820_custom.rgba16.inc.c"
};
ALIGNED8 u8 bits_2__texture_0E011020[] = {
#include "levels/bits/bits_2_0xe011020_custom.rgba16.inc.c"
};
ALIGNED8 u8 bits_2__texture_0E011820[] = {
#include "levels/bits/bits_2_0xe011820_custom.rgba16.inc.c"
};
ALIGNED8 u8 bits_2__texture_0E012020[] = {
#include "levels/bits/bits_2_0xe012020_custom.rgba16.inc.c"
};
ALIGNED8 u8 bits_2__texture_0E014020[] = {
#include "levels/bits/bits_2_0xe014020_custom.rgba16.inc.c"
};
ALIGNED8 u8 bits_2__texture_0E034420[] = {
#include "levels/bits/bits_2_0xe034420_custom.rgba16.inc.c"
};
ALIGNED8 u8 bits_2__texture_0E034430[] = {
#include "levels/bits/bits_2_0xe034430_custom.rgba16.inc.c"
};
ALIGNED8 u8 bits_2__texture_0E034440[] = {
#include "levels/bits/bits_2_0xe034440_custom.rgba16.inc.c"
};
ALIGNED8 u8 bits_2__texture_0E034450[] = {
#include "levels/bits/bits_2_0xe034450_custom.rgba16.inc.c"
};
ALIGNED8 u8 bits_2__texture_0E034460[] = {
#include "levels/bits/bits_2_0xe034460_custom.rgba16.inc.c"
};
ALIGNED8 u8 bits_2__texture_0E034470[] = {
#include "levels/bits/bits_2_0xe034470_custom.rgba16.inc.c"
};
ALIGNED8 u8 bits_2__texture_0E034480[] = {
#include "levels/bits/bits_2_0xe034480_custom.rgba16.inc.c"
};
ALIGNED8 u8 bits_2__texture_0E034490[] = {
#include "levels/bits/bits_2_0xe034490_custom.rgba16.inc.c"
};
ALIGNED8 u8 bits_2__texture_0E0344A0[] = {
#include "levels/bits/bits_2_0xe0344a0_custom.rgba16.inc.c"
};
ALIGNED8 u8 bits_2__texture_0E0344B0[] = {
#include "levels/bits/bits_2_0xe0344b0_custom.rgba16.inc.c"
};
ALIGNED8 u8 bits_2__texture_0E0344C0[] = {
#include "levels/bits/bits_2_0xe0344c0_custom.rgba16.inc.c"
};
ALIGNED8 u8 bits_2__texture_0E0344D0[] = {
#include "levels/bits/bits_2_0xe0344d0_custom.rgba16.inc.c"
};
ALIGNED8 u8 bits_2__texture_0E026020[] = {
#include "levels/bits/bits_2_0xe026020_custom.ia8.inc.c"
};
