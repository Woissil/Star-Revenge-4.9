// 0x0E000538
const GeoLayout bits_geo_000538[] = {
   GEO_CULLING_RADIUS(800),
   GEO_OPEN_NODE(),
      GEO_DISPLAY_LIST(LAYER_ALPHA, bits_seg7_dl_0700BA18),
   GEO_CLOSE_NODE(),
   GEO_END(),
};
