// 0x0E000640
const GeoLayout bits_geo_000640[] = {
   GEO_CULLING_RADIUS(600),
   GEO_OPEN_NODE(),
      GEO_DISPLAY_LIST(LAYER_OPAQUE, bits_seg7_dl_07013C78),
   GEO_CLOSE_NODE(),
   GEO_END(),
};
