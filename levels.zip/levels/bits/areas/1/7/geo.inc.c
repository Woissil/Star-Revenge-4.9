// 0x0E0004A8
const GeoLayout bits_geo_0004A8[] = {
   GEO_CULLING_RADIUS(1000),
   GEO_OPEN_NODE(),
      GEO_DISPLAY_LIST(LAYER_OPAQUE, bits_seg7_dl_07007EC8),
   GEO_CLOSE_NODE(),
   GEO_END(),
};
