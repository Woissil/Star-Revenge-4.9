static Movtex bits_2_Movtex_0_0[] = {1, 0, 15, 16, -13583, 15417, -12197, 15417, -12197, 16951, -13583, 16951, 1, 79, 0, 0};

const struct MovtexQuadCollection bits_2_Movtex_0[] = {
{0,bits_2_Movtex_0_0},
{-1, NULL},
};
const struct MovtexQuadCollection bits_2_Movtex_1[] = {
{-1, NULL},
};
const struct MovtexQuadCollection bits_2_Movtex_2[] = {
{-1, NULL},
};
