static Movtex bbh_1_Movtex_0_1[] = {1, 0, 15, 16, -16128, -1474, -9058, -1474, -9058, 3758, -16128, 3758, 0, 0, 1, 0};

const struct MovtexQuadCollection bbh_1_Movtex_0[] = {
{-1, NULL},
};
const struct MovtexQuadCollection bbh_1_Movtex_1[] = {
{0,bbh_1_Movtex_0_1},
{-1, NULL},
};
const struct MovtexQuadCollection bbh_1_Movtex_2[] = {
{-1, NULL},
};
