// 0x0E000628
const GeoLayout geo_bbh_000628[] = {
   GEO_CULLING_RADIUS(600),
   GEO_OPEN_NODE(),
      GEO_DISPLAY_LIST(LAYER_ALPHA, bbh_seg7_dl_0701FFE8),
   GEO_CLOSE_NODE(),
   GEO_END(),
};
