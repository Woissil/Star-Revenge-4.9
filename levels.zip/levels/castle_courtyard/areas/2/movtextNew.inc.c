const struct MovtexQuadCollection castle_courtyard_2_Movtex_0[] = {
{-1, NULL},
};
const struct MovtexQuadCollection castle_courtyard_2_Movtex_1[] = {
{-1, NULL},
};
const struct MovtexQuadCollection castle_courtyard_2_Movtex_2[] = {
{-1, NULL},
};
