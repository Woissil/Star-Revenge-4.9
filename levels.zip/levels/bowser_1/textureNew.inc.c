ALIGNED8 u8 bowser_1_1__texture_0E000018[] = {
#include "levels/bowser_1/bowser_1_1_0xe000018_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_1_1__texture_0E000C20[] = {
#include "levels/bowser_1/bowser_1_1_0xe000c20_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_1_1__texture_0E001C20[] = {
#include "levels/bowser_1/bowser_1_1_0xe001c20_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_1_1__texture_0E002C20[] = {
#include "levels/bowser_1/bowser_1_1_0xe002c20_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_1_1__texture_0E003420[] = {
#include "levels/bowser_1/bowser_1_1_0xe003420_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_1_1__texture_0E004420[] = {
#include "levels/bowser_1/bowser_1_1_0xe004420_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_1_1__texture_0E004C20[] = {
#include "levels/bowser_1/bowser_1_1_0xe004c20_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_1_1__texture_0E005C20[] = {
#include "levels/bowser_1/bowser_1_1_0xe005c20_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_1_1__texture_0E006420[] = {
#include "levels/bowser_1/bowser_1_1_0xe006420_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_1_1__texture_0E006C20[] = {
#include "levels/bowser_1/bowser_1_1_0xe006c20_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_1_1__texture_0E007C20[] = {
#include "levels/bowser_1/bowser_1_1_0xe007c20_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_1_1__texture_0E008420[] = {
#include "levels/bowser_1/bowser_1_1_0xe008420_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_1_1__texture_0E008C20[] = {
#include "levels/bowser_1/bowser_1_1_0xe008c20_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_1_1__texture_0E009C20[] = {
#include "levels/bowser_1/bowser_1_1_0xe009c20_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_1_1__texture_0E00A420[] = {
#include "levels/bowser_1/bowser_1_1_0xe00a420_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_1_1__texture_0E00B420[] = {
#include "levels/bowser_1/bowser_1_1_0xe00b420_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_1_1__texture_0E00BC20[] = {
#include "levels/bowser_1/bowser_1_1_0xe00bc20_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_1_1__texture_0E00E420[] = {
#include "levels/bowser_1/bowser_1_1_0xe00e420_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_1_1__texture_0E00F820[] = {
#include "levels/bowser_1/bowser_1_1_0xe00f820_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_1_1__texture_0E010020[] = {
#include "levels/bowser_1/bowser_1_1_0xe010020_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_1_1__texture_0E011620[] = {
#include "levels/bowser_1/bowser_1_1_0xe011620_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_1_1__texture_0E012620[] = {
#include "levels/bowser_1/bowser_1_1_0xe012620_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_1_1__texture_0E000820[] = {
#include "levels/bowser_1/bowser_1_1_0xe000820_custom.ia8.inc.c"
};
ALIGNED8 u8 bowser_1_1__texture_0E00CC20[] = {
#include "levels/bowser_1/bowser_1_1_0xe00cc20_custom.ci8.inc.c"
};
ALIGNED8 u8 bowser_1_1__texture_0E00CE20 = {
#include "levels/bowser_1/bowser_1_1_0xe00cc20_custom.ci8.pal.inc.c"
};
ALIGNED8 u8 bowser_1_1__texture_0E00D020[] = {
#include "levels/bowser_1/bowser_1_1_0xe00d020_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_1_1__texture_0E00D820[] = {
#include "levels/bowser_1/bowser_1_1_0xe00d820_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowser_1_1__texture_0E00E020[] = {
#include "levels/bowser_1/bowser_1_1_0xe00e020_custom.ci8.inc.c"
};
ALIGNED8 u8 bowser_1_1__texture_0E00E220 = {
#include "levels/bowser_1/bowser_1_1_0xe00e020_custom.ci8.pal.inc.c"
};
ALIGNED8 u8 bowser_1_1__texture_0E00F420[] = {
#include "levels/bowser_1/bowser_1_1_0xe00f420_custom.ci8.inc.c"
};
ALIGNED8 u8 bowser_1_1__texture_0E00F620 = {
#include "levels/bowser_1/bowser_1_1_0xe00f420_custom.ci8.pal.inc.c"
};
ALIGNED8 u8 bowser_1_1__texture_0E010820[] = {
#include "levels/bowser_1/bowser_1_1_0xe010820_custom.ci8.inc.c"
};
ALIGNED8 u8 bowser_1_1__texture_0E010A20 = {
#include "levels/bowser_1/bowser_1_1_0xe010820_custom.ci8.pal.inc.c"
};
ALIGNED8 u8 bowser_1_1__texture_0E010C20[] = {
#include "levels/bowser_1/bowser_1_1_0xe010c20_custom.ci8.inc.c"
};
ALIGNED8 u8 bowser_1_1__texture_0E011420 = {
#include "levels/bowser_1/bowser_1_1_0xe010c20_custom.ci8.pal.inc.c"
};
ALIGNED8 u8 bowser_1_1__texture_0E011E20[] = {
#include "levels/bowser_1/bowser_1_1_0xe011e20_custom.rgba16.inc.c"
};
